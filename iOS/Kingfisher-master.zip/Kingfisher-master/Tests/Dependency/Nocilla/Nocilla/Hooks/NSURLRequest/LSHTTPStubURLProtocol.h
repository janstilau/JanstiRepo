#import <Foundation/Foundation.h>

@interface LSHTTPStubURLProtocol : NSURLProtocol

@end
