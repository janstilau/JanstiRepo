#import <Foundation/Foundation.h>
#import "LSHTTPRequest.h"

@interface NSURLRequest (LSHTTPRequest)<LSHTTPRequest>

@end
