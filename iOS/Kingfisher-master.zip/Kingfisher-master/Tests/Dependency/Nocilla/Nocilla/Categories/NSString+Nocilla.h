#import <Foundation/Foundation.h>
#import "LSHTTPBody.h"

@interface NSString (Nocilla) <LSHTTPBody>

- (NSRegularExpression *)regex;

@end
