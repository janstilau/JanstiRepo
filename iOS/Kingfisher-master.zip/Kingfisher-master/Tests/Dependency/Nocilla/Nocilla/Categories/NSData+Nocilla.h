#import <Foundation/Foundation.h>
#import "LSHTTPBody.h"

@interface NSData (Nocilla) <LSHTTPBody>

@end
