//
//  MBBarView.h
//  Play-With-Sort-OC
//
//  Created by MisterBooo on 2017/7/31.
//  Copyright © 2017年 MisterBooo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MBBarView : UIView

@property(nonatomic, assign) CGRect copiedFrame;

@end
