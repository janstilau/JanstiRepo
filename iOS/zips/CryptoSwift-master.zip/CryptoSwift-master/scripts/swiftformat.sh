#!/bin/bash

swiftformat  --hexliteralcase lowercase --hexgrouping none --ranges nospace --wrapelements beforefirst --self remove $1
