//
//  Differentiator.h
//  Differentiator
//
//  Created by muukii on 7/26/17.
//  Copyright © 2017 kzaher. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for Differentiator.
FOUNDATION_EXPORT double DifferentiatorVersionNumber;

//! Project version string for Differentiator.
FOUNDATION_EXPORT const unsigned char DifferentiatorVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Differentiator/PublicHeader.h>


