
## RxExamples

To run the example app:

* Open `Rx.xcworkspace`
* Choose one of example schemes (RxExample-iOS, RxExample-macOS) and hit `Run`.

You can also run the example app using CocoaPods.

```
pod try RxSwift
```
