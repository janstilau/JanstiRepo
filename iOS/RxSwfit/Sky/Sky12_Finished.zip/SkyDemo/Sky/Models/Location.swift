//
//  Location.swift
//  Sky
//
//  Created by Mars on 29/09/2017.
//  Copyright © 2017 Mars. All rights reserved.
//

import Foundation

struct Location {
    var name: String
    var latitude: Double
    var longitude: Double
}
