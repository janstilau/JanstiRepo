//
//  URLSessionDataTask.swift
//  Sky
//
//  Created by Mars on 07/10/2017.
//  Copyright © 2017 Mars. All rights reserved.
//

import Foundation

extension URLSessionDataTask: URLSessionDataTaskProtocol {}
