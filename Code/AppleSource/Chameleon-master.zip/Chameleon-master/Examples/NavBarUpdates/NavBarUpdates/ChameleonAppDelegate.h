//  Created by Sean Heber on 1/13/11.
#import <UIKit/UIKit.h>

@interface ChameleonAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    UINavigationController *navController;
}

@end
