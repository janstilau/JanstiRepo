//
//  AppleController_Mac.m
//  MacApple
//
//  Created by Craig Hockenberry on 3/27/11.
//  Copyright 2011 The Iconfactory. All rights reserved.
//

#import "AppleController_Mac.h"

@implementation AppleController_Mac

- (UIViewController *)viewController
{
    // the view controller's view is added to the UIWindow of the UIKitView
    return myUiViewController;
}

@end
