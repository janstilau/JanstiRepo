//
//  AppleController_Mac.h
//  MacApple
//
//  Created by Craig Hockenberry on 3/27/11.
//  Copyright 2011 The Iconfactory. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppleController.h"

#import "MyUIViewController.h"

@class AppleController_Mac;

@interface AppleController_Mac : AppleController
{
}

@end
