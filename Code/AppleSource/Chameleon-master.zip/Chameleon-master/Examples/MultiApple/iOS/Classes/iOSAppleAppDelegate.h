//
//  iOSAppleAppDelegate.h
//  iOSApple
//
//  Created by Craig Hockenberry on 3/27/11.
//  Copyright 2011 The Iconfactory. All rights reserved.
//

#import <UIKit/UIKit.h>

@class AppleController_iOS;

@interface iOSAppleAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    AppleController_iOS *appleController;
}

@property (nonatomic, retain) UIWindow *window;
@property (nonatomic, retain) AppleController_iOS *appleController;

@end

