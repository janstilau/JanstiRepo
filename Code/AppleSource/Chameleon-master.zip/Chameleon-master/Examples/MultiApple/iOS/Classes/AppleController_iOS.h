//
//  AppleController_iOS.h
//  iOSApple
//
//  Created by Craig Hockenberry on 3/27/11.
//  Copyright 2011 The Iconfactory. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppleController.h"

@interface AppleController_iOS : AppleController
{
    UINavigationController *navigationController;
}

@end
